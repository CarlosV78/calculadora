document.addEventListener('DOMContentLoaded', (event) => {
    document.addEventListener('keydown', handleKeyPress);
});

function clearDisplay() {
    document.getElementById('display').value = '';
}

function appendToDisplay(value) {
    document.getElementById('display').value += value;
}

function calculateResult() {
    try {
        const result = eval(document.getElementById('display').value);
        document.getElementById('display').value = result;
    } catch (error) {
        document.getElementById('display').value = 'Error';
    }
}

function handleKeyPress(event) {
    const validKeys = '0123456789/*-+().';
    const key = event.key;

    if (key === 'Enter') {
        calculateResult();
    } else if (key === 'Backspace') {
        const display = document.getElementById('display');
        display.value = display.value.slice(0, -1);
    } else if (validKeys.includes(key)) {
        appendToDisplay(key);
    }
}
